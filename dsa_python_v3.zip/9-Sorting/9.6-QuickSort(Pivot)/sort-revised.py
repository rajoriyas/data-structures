choice = input('1:Integer\n2:Character\nEnter Choice:')
seq = list(input('Enter Statement: ').split(' '))
if choice=='1':
    seq = [int(s) for s in seq]
out=list()
def compare(seq):
	if len(seq)>0:
		pre=list()
		post=list()
		pivot=seq[-1]
		for ele in seq:
			if ele<pivot:
				pre.append(ele)
			elif ele>pivot:
				post.append(ele)
		compare(pre)
		out.append(pivot)
		compare(post)
compare(seq)
print(out)
	
