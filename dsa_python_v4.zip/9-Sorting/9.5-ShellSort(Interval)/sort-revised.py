choice = input('1:Integer\n2:Character\nEnter Choice:')
seq = list(input('Enter Statement: ').split(' '))
if choice=='1':
    seq = [int(s) for s in seq]

def compare(seq):
	interval=len(seq)//2
	while interval>0:
		i=0
		while i<(len(seq)-interval):
			if seq[i]>seq[i+interval]:
				seq[i], seq[i+interval]=seq[i+interval], seq[i]
				if i>interval:
					i=i-interval-1
			i+=1
		interval=interval//2
compare(seq)
print(seq)
