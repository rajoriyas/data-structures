class Node():
    def __init__(self, info=None, next=None):
        self.info = info
        self.next = next

class LinkedList():
    def __init__(self):
        self.node = Node()
        self.ptr = Node()
        self.len = 0

    def insert(self, info, pos=1, verbose=True):
        if self.len == 0:
            self.node = Node(info=info)
        elif self.len > 0:
            if pos == 1:
                self.node = Node(info=info, next=self.node)
            elif pos in range(2, self.len+1):
                i = 1
                self.ptr = self.node
                while i < pos-1:
                    self.ptr = self.ptr.next
                    i += 1
                self.ptr.next = Node(info=info, next=self.ptr.next)
            elif pos == self.len+1:
                i = 1
                self.ptr = self.node
                while i < pos-1:
                    self.ptr = self.ptr.next
                    i += 1
                self.ptr.next = Node(info=info)
        self.len += 1
        if verbose:
            self.show()

    def delete(self, pos=1, verbose=True):
        if self.len > 0:
            if pos == 1:
                self.node = self.node.next
            elif pos in range(1, self.len):
                i = 1
                self.ptr = self.node
                while i < pos-1:
                    self.ptr = self.ptr.next
                    i += 1
                self.ptr.next = self.ptr.next.next
            elif pos == self.len:
                i = 1
                self.ptr = self.node
                while i < pos-1:
                    self.ptr = self.ptr.next
                    i += 1
                self.ptr.next = Node()
            self.len -= 1
        if verbose:
            self.show()

    def show(self):
        i = 1
        self.ptr = self.node
        print("Linked List: ", sep="", end="")
        while i <= self.len:
            print(str(self.ptr.info)+"->", sep="", end="")
            self.ptr = self.ptr.next
            i += 1
        print('END Length: '+str(self.len))

class CircularQueue():
    def __init__(self, size):
        self.cqueue = [None]*size
        self.front = -1
        self.rear = -1
        self.size = size

    def enqueue(self, val):
        if self.front == self.rear%self.size:
            print('Overflow')
        else:
            if self.rear == -1 and self.front == -1:
                self.rear += 1
                self.front += 1
            self.cqueue[self.rear] = val
            self.rear = (self.rear+1)%self.size
        print('Circular Queue:'+ str(self.cqueue), self.rear, self.front)

    def dequeue(self):
        if self.front == -1 and self.rear == -1:
            print('Underflow')
        else:
            self.cqueue[self.front] = None
            self.front = (self.front+1)%self.size
            if self.front == self.rear%self.size:
                self.front = -1
                self.rear = -1
        print('Circular Queue:'+ str(self.cqueue), self.rear, self.front)

class Sorting():
    def __init__(self, list):
        self.list = list

    """
    MERGE SORT
    """
    def expand(self, list):
        if len(list)>1:
            mid = len(list)//2
            list = self.shrink(self.expand(list[:mid]), self.expand(list[mid:]))
        return list

    def shrink(self, pre, post):
        list = []
        i=j=0
        while i<len(pre) and j<len(post):
            if pre[i]<post[j]:
                list.append(pre[i])
                i += 1
            else:
                list.append(post[j])
                j += 1
        while i < len(pre):
            list.append(pre[i])
            i += 1
        while j < len(post):
            list.append(post[j])
            j += 1
        return list

    def merge(self):
        list = self.list
        return self.expand(list)

    """
    SHELL SORT
    """
    def shell(self, list, step=1):
        i, interval = 0, (len(list)-1)//(2**step)
        while i+interval<len(list):
            if list[i+interval]<list[i]:
                list[i+interval], list[i] = list[i], list[i+interval]
                i=interval-1
            i+=1
        if interval > 1:
            list = self.shell(list, step+1)
        return list

def main():
    """
    list = LinkedList()
    cont = True
    while cont:
        choice = input('Enter\n0: exit\n1: insert\n2: delete\n')
        if choice == '0':
            cont = False
        if choice == '1':
            print('Enter space seprated info and position:')
            info, pos = map(str, input().split())
            list.insert(info=info, pos=int(pos))
        if choice == '2':
            pos = input('Enter position:')
            list.delete(pos=int(pos))
    """
    """
    cqueue = CircularQueue(int(input('Circular Queue Size:')))
    cont = True
    while cont:
        choice = input('Enter\n0: exit\n1: insert\n2: delete\n')
        if choice == '0':
            cont = False
        if choice == '1':
            cqueue.enqueue(input('Value: '))
        if choice == '2':
            cqueue.dequeue()
    """
    sorting = Sorting(list(map(int, input('Enter Array to sort: ').split())))
    print("Sorted Array:", sorting.merge())
    print("Sorted Array:", sorting.shell(sorting.list))

if __name__ == '__main__':
    main()
